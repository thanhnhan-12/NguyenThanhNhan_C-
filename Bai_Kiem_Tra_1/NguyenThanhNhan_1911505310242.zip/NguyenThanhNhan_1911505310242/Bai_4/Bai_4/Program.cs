﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_4
{
    class Program
    {
        static void ThongTin()
        {
            Console.Write("Ho va ten: Nguyen Thanh Nhan");
            Console.Write("\nLop: 19T2");
            Console.Write("\nMa sinh vien: 1911505310242");
        }


        static void Main(string[] args)
        {
            ThongTin();

            Console.ReadKey();
        }
    }
}
